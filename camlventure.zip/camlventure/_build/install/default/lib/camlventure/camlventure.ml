(** @canonical Camlventure.Ascii *)
module Ascii = Camlventure__Ascii


(** @canonical Camlventure.Battle *)
module Battle = Camlventure__Battle


(** @canonical Camlventure.Command *)
module Command = Camlventure__Command


(** @canonical Camlventure.Display *)
module Display = Camlventure__Display


(** @canonical Camlventure.Trainerstate *)
module Trainerstate = Camlventure__Trainerstate


(** @canonical Camlventure.Ui *)
module Ui = Camlventure__Ui
